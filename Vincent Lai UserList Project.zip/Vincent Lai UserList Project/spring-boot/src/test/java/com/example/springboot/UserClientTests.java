package com.example.springboot;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.net.URL;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class UserClientTests {

	@Test
	public void expectedNumberOfUsers() {
		UserClient userClient = new UserClient();
		
		try {
			URL url = new URL("https://reqres.in/api/users?page=1");
			assertEquals(userClient.retrieveUserList(url).size(), userClient.getUserListTotal()) ;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test
	public void firstUserNamedGeorge() {
		UserClient userClient = new UserClient();
		
		try {
			URL url = new URL("https://reqres.in/api/users?page=1");
			assertEquals("George", userClient.retrieveUserList(url).get(0).getFirstName());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
